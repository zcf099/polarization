from arm import arm
from arm_exp import *

T = np.array([0.35])
params = {'N' : [100], 'D' : [1], 'E' : [[0.1]], 'T' : T, 'R' : [0.25], \
              'K' : [math.inf], 'S' : [2000000], 'P' : [0], \
              'shock' : [(None, None)], 'init' : ['norm']}
#2000000
exp = Experiment('A_evo', params, seed=3121127542,savehist=True)

exp.run()
exp.save()
exp.animate_1D(0, 0)