from arm import arm
from arm_exp import *



#expA_evo(seed=3121127542)


# for i in range(5, 11, 10):
#     x = i / 100.0
#     
   
import pickle

with open('data/expB_evo_3121127542.pkl', 'rb') as f:
    exp = pickle.load(f)

E_num = np.array([1, 2, 4, 6, 10, 50, 100])
E = [[e] for e in E_num]
params = {'N' : [100], 'D' : [1], 'E' : E, 'T' : [0.2], 'R' : [0.25], \
              'K' : [math.inf], 'S' : [20000000], 'P' : [0], \
              'shock' : [(None, None)], 'init' : ['norm']}

    
exp.plot_evo(runs=np.arange(len(exp.params)), iters=[0], tols=E_num)


