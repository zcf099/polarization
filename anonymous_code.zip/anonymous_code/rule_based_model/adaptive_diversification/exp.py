from arm import arm
from arm_exp import *



# vary diversity parameter D (T = 0.2, E' = 100).
expAD_D(seed=3121127542)

# vary T with D = 0.15 (1e8 steps; slow and ~12 GB of history).
#expAD_T(seed=3121127542)
