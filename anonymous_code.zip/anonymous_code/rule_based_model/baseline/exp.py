from arm_exp import *   # 确保导入了新函数

# 运行自定义实验，种子固定
expCustom(seed=3121127542)