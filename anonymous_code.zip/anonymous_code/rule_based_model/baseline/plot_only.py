import pickle
import numpy as np
import matplotlib.pyplot as plt
from arm_exp import Experiment

with open('data/expCustom_3121127542.pkl', 'rb') as f:
    exp = pickle.load(f)

exp.plot_evo(runs=np.arange(len(exp.params)), iters=[0],
             title='Variance over Steps (E=0.05, ultra-personalized)',
             anno='_custom_plot')