import pickle
import numpy as np
import matplotlib.pyplot as plt
from arm_exp import Experiment   # 导入 Experiment 类（用于加载时识别）

# 加载已保存的实验对象
with open('data/expCustom_3121127542.pkl', 'rb') as f:
    exp = pickle.load(f)

# 绘制所有 runs（即所有 T 值），每个 run 取第 0 次迭代
exp.plot_evo(runs=np.arange(len(exp.params)), iters=[0],
             title='Variance over Steps (E=0.05, ultra-personalized)',
             anno='_custom_plot')