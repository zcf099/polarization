from arm import arm
from arm_exp import *



#expA_evo(seed=3121127542)


# for i in range(5, 11, 10):
#     x = i / 100.0
#     
   
import pickle

with open('data/expA_evo_3121127542.pkl', 'rb') as f:
    data = f.read()
    #print(data[8970543102])
    complete_data = data[0:8970543102]
    
with open('complete_file.pkl', 'wb') as file:
    file.write(complete_data)
    
with open('data/complete_file.pkl', 'rb') as f:
    exp = pickle.load(f)

# E = [[e] for e in np.arange(1, 101, 9)]
# params = {'N' : [100], 'D' : [1], 'E' : E, 'T' : [0.3], 'R' : [0.25], \
#               'K' : [math.inf], 'S' : [2500000], 'P' : [0], \
#               'shock' : [(None, None)], 'init' : ['norm']}

T = np.arange(0.05, 1.01, 0.1)
params = {'N' : [100], 'D' : [1], 'E' : [[0.05]], 'T' : T, 'R' : [0.25], \
            'K' : [math.inf], 'S' : [100000000], 'P' : [0], \
            'shock' : [(None, None)], 'init' : ['norm']}
    
exp.plot_evo(runs=np.arange(len(exp.params)), iters=[0],tols = T)

    
#exp.plot_evo(runs=np.arange(len(exp.params)), iters=[0],tols = np.arange(1, 101, 9))


