# Code

- `llm_abm/calibrated_exposure_colab.ipynb`: the LLM-agent platform (Step 0, Step 1, pilot and gate, Studies 1-3). Run it in Google Colab with *Run all*; API keys are read from Colab Secrets (`DEEPSEEK_API_KEY`, `OPENROUTER_API_KEY`). Without keys it runs in mock mode.
- `rule_based_model/`: the rule-based model (attraction-repulsion model with tolerance-aware recommendation and adaptive diversification), in four experiment folders. In each, `python exp.py` runs the experiments and `plot_only.py`, where present, redraws figures from saved data. Requires Python 3, numpy, matplotlib and tqdm. `baseline/LICENSE` is the license of the original attraction-repulsion model code.
- `rule_based_model/adaptive_diversification/adaptive_diversification_colab.ipynb`: adaptive diversification with a numba simulator that matches `arm.py` bit for bit (*Run all* in Colab or Jupyter; also requires numba). It writes `arm_orig.py` and `arm.py` into its working directory.
